import os

rtn = os.system("ssh.exe -V")
print(rtn)

def check_ssh() -> bool:
	rtn = os.system("ssh.exe -V")
	return rtn == 0

print(os.listdir())

dlls = [dll for dll in os.listdir() if dll.endswith("dll")]
print(dlls)

for dll in dlls:
	new_name = "_" + dll
	os.rename(dll, new_name)
	if not check_ssh():
		print(f"failed: {dll}")
		os.rename(new_name, dll)
	else:
		print(f"elminated: {dll}")

print("Done")